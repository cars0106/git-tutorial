#include <stdio.h>

int main()
{
	printf("This program print result of multiply.\n");
	return 0;
}